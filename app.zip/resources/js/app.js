import './bootstrap';

import '../sass/app.scss'

import * as bootstrap from 'bootstrap'

import './bootstrap/dist/js/bootstrap.min.js'


