<?php echo e($slot); ?>

<?php /**PATH D:\tasks\laravel\pricing\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>