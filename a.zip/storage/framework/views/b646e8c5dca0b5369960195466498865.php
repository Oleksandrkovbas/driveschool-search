

<?php $__env->startSection('content'); ?>
    <div class="container h-100 mt-2">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-10 col-md-8 col-lg-6">
                <h3>
                    Update Blog
                </h3>
                <form action="<?php echo e(route('blogs.update', $post->id)); ?>" method = "POST" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group mb-3">
                        <label for="title">Title</label>
                        <input type="text" name="title" id="title" class="form-control" value = "<?php echo e($post->title); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="body">Body</label>
                        <textarea name="body" id="body" rows="3" class="form-control" required><?php echo e($post->body); ?></textarea>
                    </div>
                    <button type="submit" class="btn mt-3 btn-primary">Update Post</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tasks\laravel\pricing\resources\views/posts/edit.blade.php ENDPATH**/ ?>