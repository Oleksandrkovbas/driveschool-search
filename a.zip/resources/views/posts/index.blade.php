@extends('layouts.app')

@section('content')
    <div class="container mt-2">
        <h2>
            Blog
        </h2>
        <div class="row">
            @foreach($posts as $post)
                <div class="col-sm-12 mt-3">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">
                                {{ $post->title }}
                            </h5>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                {{ $post->body }}
                            </p>
                        </div>
                        @auth
                            <div class="card-footer">
                                <div class="row">
                                    <div class="col-6">
                                        <a href="{{route('blogs.edit', $post->id)}}" class = "btn btn-primary btn-sm">Edit</a>
                                    </div>
                                    <div class="col-6">
                                        <form action="{{ route('blogs.destroy', $post->id) }}" method = "POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endauth
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection